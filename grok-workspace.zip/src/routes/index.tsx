import { useEffect } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Toaster } from "sonner";
import { AppShell } from "@/components/tracker/app-shell";
import { CalendarHeat } from "@/components/tracker/calendar-heat";
import { DepositForm } from "@/components/tracker/deposit-form";
import { GrowthChart } from "@/components/tracker/growth-chart";
import { HeroPanel } from "@/components/tracker/hero-panel";
import { HydrateGate } from "@/components/tracker/hydrate-gate";
import { LedgerTable } from "@/components/tracker/ledger-table";
import { MilestoneTrack } from "@/components/tracker/milestone-track";
import { StatStrip } from "@/components/tracker/stat-strip";
import { useTracker } from "@/lib/store";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <HydrateGate>
      <TrackerPage />
    </HydrateGate>
  );
}

function TrackerPage() {
  const resetToSeed = useTracker((s) => s.resetToSeed);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        document.getElementById("log-amount")?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <AppShell>
      <Toaster
        theme="dark"
        position="top-center"
        toastOptions={{
          className: "!bg-panel-2 !text-paper !border-0 !shadow-[0_0_0_1px_rgba(232,230,225,0.08)]",
        }}
      />
      <div className="grid items-start gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(22rem,26rem)]">
        <HeroPanel />
        <div className="lg:pt-6">
          <DepositForm />
        </div>
      </div>
      <StatStrip />
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <GrowthChart />
        <CalendarHeat />
      </div>
      <div className="mt-6">
        <MilestoneTrack />
      </div>
      <div className="mt-6">
        <LedgerTable />
      </div>
      <footer className="mt-10 flex flex-col items-start justify-between gap-3 border-t border-line pt-6 pb-4 text-[12px] text-haze sm:flex-row sm:items-center">
        <p>K10 a day from 29 Jul 2026 to 31 Jul 2028. Numbers stay on this device.</p>
        <Button
          variant="ghost"
          size="sm"
          className="h-8 text-haze"
          onClick={() => {
            if (window.confirm("Restore the original spreadsheet figures?")) resetToSeed();
          }}
        >
          Restore spreadsheet
        </Button>
      </footer>
    </AppShell>
  );
}
