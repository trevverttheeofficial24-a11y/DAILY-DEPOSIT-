import { useEffect, useState, type ReactNode } from "react";
import { lusakaNow } from "@/lib/utils";

export function AppShell({ children }: { children: ReactNode }) {
  const [clock, setClock] = useState(() => lusakaNow());

  useEffect(() => {
    const id = window.setInterval(() => setClock(lusakaNow()), 15_000);
    return () => window.clearInterval(id);
  }, []);

  return (
    <div className="relative min-h-dvh bg-ink text-paper">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 h-72 bg-[linear-gradient(180deg,#101410_0%,#0c0d0c_100%)]"
      />
      <header className="relative z-10 mx-auto flex max-w-[1120px] items-center justify-between gap-4 px-5 pt-6 pb-2 sm:px-8 sm:pt-8">
        <div className="flex items-baseline gap-3">
          <span className="font-display text-2xl tracking-tight text-paper italic">K10</span>
          <span className="text-[13px] font-medium tracking-[0.18em] text-mist uppercase">
            Daily
          </span>
        </div>
        <div className="flex items-center gap-3 text-[13px] text-mist">
          <span className="hidden sm:inline">
            {clock.weekday} {clock.date}
          </span>
          <span className="flex items-center gap-2 tabular-nums">
            <span className="live-dot size-1.5 rounded-full bg-sage" />
            {clock.time} CAT
          </span>
        </div>
      </header>
      <main className="relative z-10 mx-auto max-w-[1120px] px-5 pb-24 sm:px-8 sm:pb-16">
        {children}
      </main>
    </div>
  );
}
