import { useEffect, useState } from "react";
import { AnimatedNumber } from "./animated-number";
import { ProgressRing } from "./progress-ring";
import { useTracker, useTrackerStats } from "@/lib/store";
import { formatK, formatDay } from "@/lib/utils";
import { TARGET_DATE } from "@/lib/tracker-data";

export function HeroPanel() {
  const stats = useTrackerStats();
  const burstId = useTracker((s) => s.burstId);
  const [ringSize, setRingSize] = useState(220);

  useEffect(() => {
    const apply = () => setRingSize(window.innerWidth < 640 ? 208 : 248);
    apply();
    window.addEventListener("resize", apply);
    return () => window.removeEventListener("resize", apply);
  }, []);

  const pct = Math.round(stats.progress * 1000) / 10;
  const paceLabel =
    stats.paceDelta > 0
      ? `${formatK(stats.paceDelta, 0)} ahead of K10/day`
      : stats.paceDelta < 0
        ? `${formatK(Math.abs(stats.paceDelta), 0)} behind K10/day`
        : "Exactly on the K10/day pace";

  return (
    <section className="stagger-in flex flex-col items-center pt-4 pb-2 sm:pt-6">
      <p className="text-[13px] tracking-[0.22em] text-mist uppercase">Patumba · running total</p>
      <ProgressRing
        progress={stats.progress}
        burst={burstId > 0}
        className="mt-4"
        size={ringSize}
      >
        <AnimatedNumber
          value={stats.cashBalance}
          className="font-display text-[2.75rem] leading-none tracking-tight text-paper sm:text-5xl"
        />
        <span className="mt-2 max-w-[11rem] text-[12px] leading-snug text-mist">
          {pct}% of {formatK(stats.planTarget, 0)}
        </span>
      </ProgressRing>
      <p className="mt-3 max-w-sm text-center text-sm text-paper/80">{paceLabel}</p>
      <p className="mt-1 text-[12px] text-haze">
        Target {formatDay(TARGET_DATE, "short")} · {stats.daysRemaining} days left
      </p>
    </section>
  );
}
