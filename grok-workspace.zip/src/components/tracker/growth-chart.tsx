import { useEffect, useMemo, useState } from "react";
import {
  Area,
  CartesianGrid,
  ComposedChart,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { useTracker, useTrackerStats } from "@/lib/store";
import { chartSeries } from "@/lib/tracker-data";
import { formatK } from "@/lib/utils";

type TipProps = {
  active?: boolean;
  payload?: Array<{ name: string; value: number; color: string }>;
  label?: string;
};

function ChartTip({ active, payload, label }: TipProps) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-md bg-panel-2 px-3 py-2 text-xs shadow-[var(--shadow-border)]">
      <div className="mb-1 text-mist">{label}</div>
      {payload.map((p) => (
        <div key={p.name} className="flex items-center justify-between gap-6 tabular-nums text-paper">
          <span className="text-mist">{p.name}</span>
          <span>{p.value == null ? "—" : formatK(p.value)}</span>
        </div>
      ))}
    </div>
  );
}

export function GrowthChart() {
  const days = useTracker((s) => s.days);
  const stats = useTrackerStats();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const data = useMemo(() => chartSeries(days, stats.today), [days, stats.today]);

  return (
    <section className="rounded-xl bg-panel p-5 shadow-[var(--shadow-border)] sm:p-6">
      <div className="flex items-end justify-between gap-3">
        <div>
          <h2 className="font-display text-2xl tracking-tight">Growth</h2>
          <p className="mt-1 text-sm text-mist">Deposits vs the K10/day line, with Patumba balance overlaid.</p>
        </div>
        <div className="hidden items-center gap-4 text-[11px] tracking-wide text-mist uppercase sm:flex">
          <span className="flex items-center gap-1.5">
            <i className="block size-2 rounded-full bg-sage" /> Cash
          </span>
          <span className="flex items-center gap-1.5">
            <i className="block size-2 rounded-full bg-paper/70" /> Deposited
          </span>
          <span className="flex items-center gap-1.5">
            <i className="block size-2 rounded-full bg-haze" /> Pace
          </span>
        </div>
      </div>
      <div className="mt-4 h-56 sm:h-64">
        {mounted && data.length ? (
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={data} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
              <defs>
                <linearGradient id="cashFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#7ea894" stopOpacity={0.28} />
                  <stop offset="100%" stopColor="#7ea894" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="#2a2d2a" vertical={false} />
              <XAxis
                dataKey="label"
                tick={{ fill: "#8b8f8a", fontSize: 11 }}
                tickLine={false}
                axisLine={false}
                interval="preserveStartEnd"
                minTickGap={28}
              />
              <YAxis
                tick={{ fill: "#8b8f8a", fontSize: 11 }}
                tickLine={false}
                axisLine={false}
                tickFormatter={(v: number) => (v >= 1000 ? `${v / 1000}k` : String(v))}
                width={40}
              />
              <Tooltip content={<ChartTip />} />
              <Area
                type="monotone"
                dataKey="bank"
                name="Patumba"
                stroke="#7ea894"
                fill="url(#cashFill)"
                strokeWidth={2}
                dot={false}
                connectNulls
              />
              <Line
                type="monotone"
                dataKey="deposited"
                name="Deposited"
                stroke="#e8e6e1"
                strokeWidth={1.5}
                dot={false}
              />
              <Line
                type="monotone"
                dataKey="expected"
                name="K10 pace"
                stroke="#5c605c"
                strokeWidth={1}
                strokeDasharray="4 4"
                dot={false}
              />
            </ComposedChart>
          </ResponsiveContainer>
        ) : data.length === 0 ? (
          <div className="flex h-full items-center justify-center text-sm text-mist">Waiting for deposits</div>
        ) : null}
      </div>
      <p className="mt-3 text-[12px] text-haze">
        At the current {formatK(stats.averageDeposit, 0)} average, the plan lands near{" "}
        {formatK(stats.projectedTotal, 0)} by July 2028.
      </p>
    </section>
  );
}
