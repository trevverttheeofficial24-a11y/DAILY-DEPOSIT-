import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useTracker } from "@/lib/store";
import { crossedOn, LUSE_COUNTERS, type Milestone } from "@/lib/tracker-data";
import { cn, formatDay, formatK, todayISO } from "@/lib/utils";
import { Check, Landmark } from "lucide-react";

export function MilestoneTrack() {
  const days = useTracker((s) => s.days);
  const milestones = useTracker((s) => s.milestones);
  const updateMilestone = useTracker((s) => s.updateMilestone);
  const [open, setOpen] = useState<number | null>(null);

  const rows = useMemo(
    () =>
      milestones.map((m) => ({
        ...m,
        crossed: crossedOn(days, m.threshold),
      })),
    [days, milestones],
  );

  const active = rows.find((r) => r.threshold === open) ?? null;
  const nextReady = rows.find((r) => r.crossed && r.amountInvested == null);

  return (
    <section className="rounded-xl bg-panel p-5 shadow-[var(--shadow-border)] sm:p-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h2 className="font-display text-2xl tracking-tight">LuSE milestones</h2>
          <p className="mt-1 max-w-xl text-sm text-mist">
            When the pot crosses a rung, move that chunk into shares instead of waiting until 2028.
          </p>
        </div>
        {nextReady ? (
          <span className="self-start rounded-full bg-sage-dim px-3 py-1 text-[12px] font-medium text-sage-2">
            {formatK(nextReady.threshold, 0)} ready to invest
          </span>
        ) : null}
      </div>

      <ol className="mt-6 space-y-2">
        {rows.map((row, i) => {
          const invested = row.amountInvested != null && row.amountInvested > 0;
          const ready = !!row.crossed && !invested;
          return (
            <li key={row.threshold}>
              <button
                type="button"
                onClick={() => setOpen(row.threshold)}
                className={cn(
                  "flex w-full items-center gap-4 rounded-lg px-3 py-3 text-left transition-[background-color,box-shadow] duration-150 sm:px-4",
                  ready && "bg-sage-dim/60 shadow-[var(--shadow-border)]",
                  invested && "bg-ink-2",
                  !ready && !invested && "hover:bg-panel-2",
                )}
              >
                <span
                  className={cn(
                    "grid size-9 shrink-0 place-items-center rounded-full text-[12px] font-medium",
                    invested && "bg-sage text-sage-fg",
                    ready && "bg-sage/30 text-sage-2",
                    !ready && !invested && "bg-panel-2 text-haze",
                  )}
                >
                  {invested ? <Check className="size-4" /> : i + 1}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex flex-wrap items-baseline gap-x-2">
                    <span className="font-medium tabular-nums text-paper">{formatK(row.threshold, 0)}</span>
                    {invested ? (
                      <span className="truncate text-sm text-mist">
                        {row.company || row.ticker || "Trade recorded"}
                      </span>
                    ) : ready ? (
                      <span className="text-sm text-sage-2">
                        Threshold crossed {formatDay(row.crossed!, "short")}
                      </span>
                    ) : (
                      <span className="text-sm text-haze">Upcoming</span>
                    )}
                  </span>
                  {invested && row.amountInvested != null ? (
                    <span className="block text-[12px] text-mist">
                      {formatK(row.amountInvested)} deployed
                      {row.dateInvested ? ` · ${formatDay(row.dateInvested, "short")}` : ""}
                    </span>
                  ) : null}
                </span>
                <span className="hidden text-[12px] text-haze sm:inline">
                  {invested ? "Edit" : ready ? "Record buy" : "Prep"}
                </span>
              </button>
            </li>
          );
        })}
      </ol>

      <aside className="mt-5 flex gap-3 rounded-lg bg-ink-2 p-4 text-sm text-mist">
        <Landmark className="mt-0.5 size-4 shrink-0 text-sage" />
        <p>
          Before the first kwacha hits the exchange, call a licensed broker (Pangaea Securities or Stockbrokers Zambia)
          and ask: minimum trade size, fee per trade, and any account minimums. That answer decides small frequent buys
          versus fewer larger ones.
        </p>
      </aside>

      <InvestDialog
        row={active}
        onClose={() => setOpen(null)}
        onSave={(patch) => {
          if (!active) return;
          updateMilestone(active.threshold, patch);
          setOpen(null);
          toast.success(
            patch.amountInvested
              ? `Recorded ${formatK(patch.amountInvested)} in ${patch.company || "LuSE"}`
              : "Milestone updated",
          );
        }}
      />
    </section>
  );
}

function InvestDialog({
  row,
  onClose,
  onSave,
}: {
  row: (Milestone & { crossed: string | null }) | null;
  onClose: () => void;
  onSave: (patch: Partial<Milestone>) => void;
}) {
  return (
    <Dialog open={!!row} onOpenChange={(v) => { if (!v) onClose(); }}>
      <DialogContent className="bg-panel">
        {row ? <InvestForm key={row.threshold} row={row} onClose={onClose} onSave={onSave} /> : null}
      </DialogContent>
    </Dialog>
  );
}

function InvestForm({
  row,
  onClose,
  onSave,
}: {
  row: Milestone & { crossed: string | null };
  onClose: () => void;
  onSave: (patch: Partial<Milestone>) => void;
}) {
  const [company, setCompany] = useState(row.company);
  const [ticker, setTicker] = useState(row.ticker);
  const [amount, setAmount] = useState(
    row.amountInvested == null ? String(row.threshold) : String(row.amountInvested),
  );
  const [date, setDate] = useState(row.dateInvested || todayISO());
  const [fees, setFees] = useState(row.feesConfirmed);
  const [notes, setNotes] = useState(row.notes);

  return (
    <>
      <DialogHeader>
        <DialogTitle>{formatK(row.threshold, 0)} rung</DialogTitle>
        <DialogDescription>
          {row.crossed
            ? `Savings crossed this level on ${formatDay(row.crossed, "short")}. Record the actual buy when it happens.`
            : "Prep the trade. Fill this in once the broker confirms."}
        </DialogDescription>
      </DialogHeader>

      <div className="grid gap-3">
        <div className="grid gap-2">
          <Label htmlFor="ms-counter">Counter</Label>
          <select
            id="ms-counter"
            value={ticker}
            onChange={(e) => {
              const t = e.target.value;
              setTicker(t);
              const hit = LUSE_COUNTERS.find((c) => c.ticker === t);
              if (hit) setCompany(hit.name);
            }}
            className="flex h-11 w-full rounded-md bg-ink-2 px-3 text-sm text-paper shadow-[var(--shadow-border)] focus-visible:outline-none focus-visible:shadow-[0_0_0_1px_rgba(126,168,148,0.55)]"
          >
            <option value="">Choose a LuSE counter</option>
            {LUSE_COUNTERS.map((c) => (
              <option key={c.ticker} value={c.ticker}>
                {c.ticker} — {c.name}
              </option>
            ))}
            <option value="OTHER">Other</option>
          </select>
        </div>
        <div className="grid gap-2">
          <Label htmlFor="ms-company">Company</Label>
          <Input id="ms-company" value={company} onChange={(e) => setCompany(e.target.value)} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="grid gap-2">
            <Label htmlFor="ms-amount">Amount invested (K)</Label>
            <Input
              id="ms-amount"
              inputMode="decimal"
              className="tabular-nums"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="ms-date">Trade date</Label>
            <Input id="ms-date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </div>
        </div>
        <label className="flex min-h-11 items-center gap-2 text-sm text-mist">
          <input
            type="checkbox"
            checked={fees}
            onChange={(e) => setFees(e.target.checked)}
            className="size-4 rounded-sm accent-sage"
          />
          Broker fees confirmed
        </label>
        <div className="grid gap-2">
          <Label htmlFor="ms-notes">Notes</Label>
          <Input id="ms-notes" value={notes} onChange={(e) => setNotes(e.target.value)} />
        </div>
      </div>

      <DialogFooter>
        <Button variant="ghost" onClick={onClose}>
          Cancel
        </Button>
        <Button
          onClick={() => {
            const named =
              company || LUSE_COUNTERS.find((c) => c.ticker === ticker)?.name || "";
            onSave({
              company: named,
              ticker,
              amountInvested: amount === "" ? null : Number(amount),
              dateInvested: date,
              feesConfirmed: fees,
              notes,
            });
          }}
        >
          Save trade
        </Button>
      </DialogFooter>
    </>
  );
}

