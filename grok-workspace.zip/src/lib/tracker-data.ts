import { addDaysISO, diffDays, parseISODate, round2, todayISO, toISODate } from "./utils";

export const START_DATE = "2026-07-29";
export const TARGET_DATE = "2028-07-31";
export const DAILY_TARGET = 10;
export const PLAN_DAYS = diffDays(START_DATE, TARGET_DATE) + 1;
export const PLAN_TARGET = PLAN_DAYS * DAILY_TARGET;

export type DayEntry = {
  date: string;
  deposit: number | null;
  bankBalance: number | null;
  notes: string;
};

export type DayView = DayEntry & {
  cumulative: number;
  interest: number | null;
  expected: number;
};

export type Milestone = {
  threshold: number;
  dateInvested: string;
  company: string;
  ticker: string;
  amountInvested: number | null;
  feesConfirmed: boolean;
  notes: string;
};

export type SeedLog = {
  date: string;
  deposit: number;
  bankBalance: number;
  notes: string;
};

export const LUSE_COUNTERS = [
  { ticker: "ATEL", name: "Airtel Networks Zambia" },
  { ticker: "CEC", name: "Copperbelt Energy Corporation" },
  { ticker: "ZCCM", name: "ZCCM Investments Holdings" },
  { ticker: "ZSUG", name: "Zambia Sugar" },
  { ticker: "ZNCO", name: "Zanaco" },
  { ticker: "SCBL", name: "Standard Chartered Bank Zambia" },
  { ticker: "ZAMB", name: "Zambeef Products" },
  { ticker: "REIZ", name: "Real Estate Investments Zambia" },
  { ticker: "MAFS", name: "Madison Financial Services" },
  { ticker: "LAFA", name: "Lafarge Zambia" },
  { ticker: "SHOP", name: "Shoprite Holdings" },
  { ticker: "PUMA", name: "Puma Energy Zambia" },
  { ticker: "NATB", name: "National Breweries" },
] as const;

export const SEED_LOGS: SeedLog[] = [
  { date: "2026-07-29", deposit: 10, bankBalance: 10, notes: "Deposited Successfully" },
  { date: "2026-07-30", deposit: 10, bankBalance: 20, notes: "Deposited Successfully" },
  { date: "2026-07-31", deposit: 10, bankBalance: 30, notes: "Deposited Successfully" },
  { date: "2026-08-01", deposit: 10, bankBalance: 40.01, notes: "Deposited Successfully" },
  { date: "2026-08-02", deposit: 10, bankBalance: 50.01, notes: "Deposited Successfully" },
  { date: "2026-08-03", deposit: 10, bankBalance: 60.01, notes: "Deposited Successfully" },
  { date: "2026-08-04", deposit: 10, bankBalance: 70.02, notes: "Deposited Successfully" },
  { date: "2026-08-05", deposit: 10, bankBalance: 80.03, notes: "Deposited Successfully" },
  { date: "2026-08-06", deposit: 20, bankBalance: 100.04, notes: "Deposited Successfully" },
  { date: "2026-08-07", deposit: 10, bankBalance: 110.05, notes: "Deposited Successfully" },
  { date: "2026-08-08", deposit: 10, bankBalance: 120.05, notes: "Deposited Successfully" },
  { date: "2026-08-09", deposit: 10, bankBalance: 130.06, notes: "Deposited Successfully" },
  { date: "2026-08-10", deposit: 10, bankBalance: 140.07, notes: "Deposited Successfully" },
  { date: "2026-08-11", deposit: 20, bankBalance: 160.09, notes: "Deposited Successfully" },
  { date: "2026-08-12", deposit: 15, bankBalance: 175.09, notes: "Deposited Successfully" },
  { date: "2026-08-13", deposit: 10, bankBalance: 185.11, notes: "Deposited Successfully" },
  { date: "2026-08-14", deposit: 15, bankBalance: 200.12, notes: "Deposited Successfully" },
  { date: "2026-08-15", deposit: 10, bankBalance: 210.15, notes: "Deposited Successfully" },
  { date: "2026-08-16", deposit: 10, bankBalance: 220.15, notes: "Deposited Successfully" },
  { date: "2026-08-17", deposit: 7, bankBalance: 227.19, notes: "Deposited Successfully" },
  { date: "2026-08-18", deposit: 10, bankBalance: 237.23, notes: "Deposited Successfully" },
  { date: "2026-08-19", deposit: 13, bankBalance: 250.28, notes: "Deposited Successfully" },
  { date: "2026-08-20", deposit: 10, bankBalance: 260.28, notes: "Deposited Successfully" },
  { date: "2026-08-21", deposit: 10, bankBalance: 270.34, notes: "Deposited Successfully" },
  { date: "2026-08-22", deposit: 10, bankBalance: 280.39, notes: "Deposited Successfully" },
  { date: "2026-08-23", deposit: 20, bankBalance: 300.5, notes: "Deposited Successfully" },
  { date: "2026-08-24", deposit: 10, bankBalance: 310.5, notes: "Deposited Successfully" },
  { date: "2026-08-25", deposit: 20, bankBalance: 330.62, notes: "Deposited Successfully" },
  { date: "2026-08-26", deposit: 15, bankBalance: 345.69, notes: "Deposited Successfully" },
  { date: "2026-08-27", deposit: 10, bankBalance: 355.69, notes: "Deposited Successfully" },
  { date: "2026-08-28", deposit: 25, bankBalance: 380.82, notes: "Deposited Successfully" },
  { date: "2026-08-29", deposit: 20, bankBalance: 400.9, notes: "Deposited Successfully" },
  { date: "2026-08-30", deposit: 10, bankBalance: 410.9, notes: "Deposited Successfully" },
  { date: "2026-08-31", deposit: 10, bankBalance: 420.98, notes: "Deposited Successfully" },
  { date: "2026-09-01", deposit: 10, bankBalance: 431.05, notes: "Deposited Successfully" },
  { date: "2026-09-02", deposit: 10, bankBalance: 441.29, notes: "Deposited Successfully" },
  { date: "2026-09-03", deposit: 10, bankBalance: 451.42, notes: "Deposited Successfully" },
  { date: "2026-09-04", deposit: 10, bankBalance: 461.54, notes: "Deposited Successfully" },
  { date: "2026-09-05", deposit: 10, bankBalance: 471.67, notes: "Deposited Successfully" },
  { date: "2026-09-06", deposit: 20, bankBalance: 491.8, notes: "Deposited Successfully" },
  { date: "2026-09-07", deposit: 10, bankBalance: 501.8, notes: "Deposited Successfully" },
  { date: "2026-09-08", deposit: 0, bankBalance: 502.07, notes: "No Deposit Made" },
  { date: "2026-09-09", deposit: 11, bankBalance: 513.2, notes: "Deposited Successfully" },
  { date: "2026-09-10", deposit: 19, bankBalance: 532.34, notes: "Deposited Successfully" },
  { date: "2026-09-11", deposit: 10, bankBalance: 542.48, notes: "Deposited Successfully" },
];

export const SEED_MILESTONES: Milestone[] = [500, 1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000].map(
  (threshold) => ({
    threshold,
    dateInvested: "",
    company: "",
    ticker: "",
    amountInvested: null,
    feesConfirmed: false,
    notes: "",
  }),
);

export function buildCalendar(logs: SeedLog[] = SEED_LOGS): DayEntry[] {
  const map = new Map(logs.map((l) => [l.date, l]));
  const days: DayEntry[] = [];
  let iso = START_DATE;
  while (iso <= TARGET_DATE) {
    const log = map.get(iso);
    days.push({
      date: iso,
      deposit: log ? log.deposit : null,
      bankBalance: log ? log.bankBalance : null,
      notes: log?.notes ?? "",
    });
    iso = addDaysISO(iso, 1);
  }
  return days;
}

export function mergeCalendar(stored: DayEntry[]): DayEntry[] {
  const fresh = buildCalendar();
  const map = new Map(stored.map((d) => [d.date, d]));
  return fresh.map((d) => map.get(d.date) ?? d);
}

export function withViews(days: DayEntry[]): DayView[] {
  let cumulative = 0;
  let index = 0;
  return days.map((d) => {
    if (d.deposit != null) cumulative = round2(cumulative + d.deposit);
    const interest = d.bankBalance != null ? round2(d.bankBalance - cumulative) : null;
    index += 1;
    return {
      ...d,
      cumulative,
      interest,
      expected: index * DAILY_TARGET,
    };
  });
}

export type TrackerStats = {
  today: string;
  totalDeposited: number;
  cashBalance: number;
  interest: number;
  daysElapsed: number;
  daysLogged: number;
  daysWithDeposit: number;
  daysRemaining: number;
  averageDeposit: number;
  expectedByNow: number;
  paceDelta: number;
  planTarget: number;
  progress: number;
  streak: number;
  longestStreak: number;
  missedDays: number;
  lastLoggedDate: string | null;
  projectedTotal: number;
  invested: number;
  netWorth: number;
};

export function computeStats(days: DayEntry[], milestones: Milestone[]): TrackerStats {
  const today = todayISO();
  const views = withViews(days);
  const elapsed = views.filter((d) => d.date <= today);
  const logged = elapsed.filter((d) => d.deposit != null);
  const withDeposit = logged.filter((d) => (d.deposit ?? 0) > 0);
  const totalDeposited = round2(logged.reduce((s, d) => s + (d.deposit ?? 0), 0));
  const lastBank = [...elapsed].reverse().find((d) => d.bankBalance != null);
  const cashBalance = lastBank?.bankBalance ?? totalDeposited;
  const interest = lastBank?.interest ?? 0;
  const daysElapsed = elapsed.length;
  const expectedByNow = daysElapsed * DAILY_TARGET;
  const averageDeposit = logged.length ? round2(totalDeposited / logged.length) : 0;
  const remaining = views.filter((d) => d.date > today).length;
  const projectedTotal = round2(totalDeposited + remaining * averageDeposit);
  const invested = round2(
    milestones.reduce((s, m) => s + (m.amountInvested ?? 0), 0),
  );
  const { streak, longestStreak } = computeStreaks(elapsed);
  const missedDays = elapsed.filter((d) => d.deposit === 0 || d.deposit === null).length;
  const lastLoggedDate = [...logged].reverse()[0]?.date ?? null;

  return {
    today,
    totalDeposited,
    cashBalance,
    interest,
    daysElapsed,
    daysLogged: logged.length,
    daysWithDeposit: withDeposit.length,
    daysRemaining: remaining,
    averageDeposit,
    expectedByNow,
    paceDelta: round2(totalDeposited - expectedByNow),
    planTarget: PLAN_TARGET,
    progress: PLAN_TARGET ? totalDeposited / PLAN_TARGET : 0,
    streak,
    longestStreak,
    missedDays,
    lastLoggedDate,
    projectedTotal,
    invested,
    netWorth: round2(cashBalance + invested),
  };
}

function computeStreaks(elapsed: DayEntry[]): { streak: number; longestStreak: number } {
  let streak = 0;
  let longest = 0;
  let run = 0;
  for (const d of elapsed) {
    if ((d.deposit ?? 0) > 0) {
      run += 1;
      longest = Math.max(longest, run);
    } else {
      run = 0;
    }
  }
  streak = run;
  return { streak, longestStreak: longest };
}

export function firstUnloggedDate(days: DayEntry[], today: string): string {
  const gap = days.find((d) => d.date <= today && d.deposit === null);
  return gap?.date ?? today;
}

export function crossedOn(days: DayEntry[], threshold: number): string | null {
  const views = withViews(days);
  const hit = views.find((d) => d.deposit != null && d.cumulative >= threshold);
  return hit?.date ?? null;
}

export function chartSeries(days: DayEntry[], today: string) {
  const views = withViews(days).filter((d) => d.date <= today && d.deposit != null);
  return views.map((d) => ({
    date: d.date,
    deposited: d.cumulative,
    bank: d.bankBalance,
    expected: d.expected,
    label: d.date.slice(5),
  }));
}

export function monthKey(iso: string): string {
  return iso.slice(0, 7);
}

export function monthsInPlan(): string[] {
  const months: string[] = [];
  const start = parseISODate(START_DATE);
  const end = parseISODate(TARGET_DATE);
  const cursor = new Date(start.getFullYear(), start.getMonth(), 1);
  while (cursor <= end) {
    months.push(toISODate(cursor).slice(0, 7));
    cursor.setMonth(cursor.getMonth() + 1);
  }
  return months;
}

export function weekdayIndex(iso: string): number {
  return parseISODate(iso).getDay();
}
