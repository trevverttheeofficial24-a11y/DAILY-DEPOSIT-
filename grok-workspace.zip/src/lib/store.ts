import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  buildCalendar,
  computeStats,
  firstUnloggedDate,
  mergeCalendar,
  SEED_MILESTONES,
  type DayEntry,
  type Milestone,
  type TrackerStats,
  withViews,
} from "./tracker-data";
import { todayISO } from "./utils";

type LogPayload = {
  date: string;
  deposit: number;
  bankBalance: number | null;
  notes: string;
};

type TrackerState = {
  days: DayEntry[];
  milestones: Milestone[];
  selectedDate: string;
  burstId: number;
  hydrated: boolean;
  setSelectedDate: (date: string) => void;
  logDeposit: (payload: LogPayload) => { crossed: number[] };
  updateMilestone: (threshold: number, patch: Partial<Milestone>) => void;
  resetToSeed: () => void;
  hydrate: () => void;
};

export const useTracker = create<TrackerState>()(
  persist(
    (set, get) => ({
      days: buildCalendar(),
      milestones: SEED_MILESTONES,
      selectedDate: todayISO(),
      burstId: 0,
      hydrated: false,
      setSelectedDate: (date) => set({ selectedDate: date }),
      logDeposit: (payload) => {
        const before = withViews(get().days);
        const prevCum = before.find((d) => d.date === payload.date)?.cumulative ?? 0;
        const prevDeposit = before.find((d) => d.date === payload.date)?.deposit ?? 0;
        const prevTotal = prevCum - (prevDeposit ?? 0);

        set((state) => ({
          days: state.days.map((d) =>
            d.date === payload.date
              ? {
                  ...d,
                  deposit: payload.deposit,
                  bankBalance: payload.bankBalance,
                  notes: payload.notes,
                }
              : d,
          ),
          selectedDate: payload.date,
          burstId: payload.deposit > 0 ? state.burstId + 1 : state.burstId,
        }));

        const after = withViews(get().days);
        const newCum = after.find((d) => d.date === payload.date)?.cumulative ?? 0;
        const thresholds = get().milestones.map((m) => m.threshold);
        const crossed = thresholds.filter((t) => prevTotal < t && newCum >= t);
        return { crossed };
      },
      updateMilestone: (threshold, patch) =>
        set((state) => ({
          milestones: state.milestones.map((m) =>
            m.threshold === threshold ? { ...m, ...patch } : m,
          ),
        })),
      resetToSeed: () =>
        set({
          days: buildCalendar(),
          milestones: SEED_MILESTONES,
          selectedDate: todayISO(),
        }),
      hydrate: () => {
        if (get().hydrated) return;
        const stored = get().days;
        const today = todayISO();
        set({
          days: mergeCalendar(stored),
          selectedDate: firstUnloggedDate(mergeCalendar(stored), today),
          hydrated: true,
        });
      },
    }),
    {
      name: "k10-daily-v1",
      skipHydration: true,
      partialize: (state) => ({
        days: state.days,
        milestones: state.milestones,
      }),
    },
  ),
);

export function useTrackerStats(): TrackerStats {
  const days = useTracker((s) => s.days);
  const milestones = useTracker((s) => s.milestones);
  return computeStats(days, milestones);
}
