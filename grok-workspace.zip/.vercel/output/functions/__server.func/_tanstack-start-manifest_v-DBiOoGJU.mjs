//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DBiOoGJU.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Cag7bKbn.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Cag7bKbn.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-1WmF9F2x.js"]
	}
} });
//#endregion
export { tsrStartManifest };
