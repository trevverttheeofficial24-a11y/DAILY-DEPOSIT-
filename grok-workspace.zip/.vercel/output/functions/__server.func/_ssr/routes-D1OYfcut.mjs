import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Landmark, c as Check, i as Minus, o as ChevronRight, r as Plus, s as ChevronLeft, t as X } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { a as DialogOverlay$1, g as Slot, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { a as Trigger, i as Root3, n as Portal, r as Provider, t as Content2 } from "../_libs/@radix-ui/react-tooltip+[...].mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
import { a as Line, c as Tooltip, i as Area, n as YAxis, o as CartesianGrid, r as XAxis, s as ResponsiveContainer, t as ComposedChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D1OYfcut.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function todayISO() {
	return new Intl.DateTimeFormat("en-CA", {
		timeZone: "Africa/Lusaka",
		year: "numeric",
		month: "2-digit",
		day: "2-digit"
	}).format(/* @__PURE__ */ new Date());
}
function formatK(value, decimals = 2) {
	const formatted = Math.abs(value).toLocaleString("en-ZM", {
		minimumFractionDigits: decimals,
		maximumFractionDigits: decimals
	});
	return `${value < 0 ? "−" : ""}K${formatted}`;
}
function formatDay(iso, style = "full") {
	const d = parseISODate(iso);
	if (style === "short") return new Intl.DateTimeFormat("en-GB", {
		weekday: "short",
		day: "numeric",
		month: "short"
	}).format(d);
	if (style === "month") return new Intl.DateTimeFormat("en-GB", {
		month: "long",
		year: "numeric"
	}).format(d);
	return new Intl.DateTimeFormat("en-GB", {
		weekday: "long",
		day: "numeric",
		month: "long",
		year: "numeric"
	}).format(d);
}
function parseISODate(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	return new Date(y, (m ?? 1) - 1, d ?? 1);
}
function toISODate(date) {
	return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
function addDaysISO(iso, days) {
	const d = parseISODate(iso);
	d.setDate(d.getDate() + days);
	return toISODate(d);
}
function diffDays(fromISO, toISO) {
	const a = parseISODate(fromISO);
	const b = parseISODate(toISO);
	return Math.round((b.getTime() - a.getTime()) / 864e5);
}
function round2(n) {
	return Math.round(n * 100) / 100;
}
function lusakaNow() {
	const now = /* @__PURE__ */ new Date();
	return {
		time: new Intl.DateTimeFormat("en-GB", {
			timeZone: "Africa/Lusaka",
			hour: "2-digit",
			minute: "2-digit",
			hour12: false
		}).format(now),
		weekday: new Intl.DateTimeFormat("en-GB", {
			timeZone: "Africa/Lusaka",
			weekday: "short"
		}).format(now),
		date: new Intl.DateTimeFormat("en-GB", {
			timeZone: "Africa/Lusaka",
			day: "numeric",
			month: "short"
		}).format(now)
	};
}
function AppShell({ children }) {
	const [clock, setClock] = (0, import_react.useState)(() => lusakaNow());
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setClock(lusakaNow()), 15e3);
		return () => window.clearInterval(id);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-dvh bg-ink text-paper",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": "true",
				className: "pointer-events-none absolute inset-x-0 top-0 h-72 bg-[linear-gradient(180deg,#101410_0%,#0c0d0c_100%)]"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "relative z-10 mx-auto flex max-w-[1120px] items-center justify-between gap-4 px-5 pt-6 pb-2 sm:px-8 sm:pt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-2xl tracking-tight text-paper italic",
						children: "K10"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[13px] font-medium tracking-[0.18em] text-mist uppercase",
						children: "Daily"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 text-[13px] text-mist",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "hidden sm:inline",
						children: [
							clock.weekday,
							" ",
							clock.date
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2 tabular-nums",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "live-dot size-1.5 rounded-full bg-sage" }),
							clock.time,
							" CAT"
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "relative z-10 mx-auto max-w-[1120px] px-5 pb-24 sm:px-8 sm:pb-16",
				children
			})
		]
	});
}
var START_DATE = "2026-07-29";
var TARGET_DATE = "2028-07-31";
var PLAN_TARGET = (diffDays(START_DATE, TARGET_DATE) + 1) * 10;
var LUSE_COUNTERS = [
	{
		ticker: "ATEL",
		name: "Airtel Networks Zambia"
	},
	{
		ticker: "CEC",
		name: "Copperbelt Energy Corporation"
	},
	{
		ticker: "ZCCM",
		name: "ZCCM Investments Holdings"
	},
	{
		ticker: "ZSUG",
		name: "Zambia Sugar"
	},
	{
		ticker: "ZNCO",
		name: "Zanaco"
	},
	{
		ticker: "SCBL",
		name: "Standard Chartered Bank Zambia"
	},
	{
		ticker: "ZAMB",
		name: "Zambeef Products"
	},
	{
		ticker: "REIZ",
		name: "Real Estate Investments Zambia"
	},
	{
		ticker: "MAFS",
		name: "Madison Financial Services"
	},
	{
		ticker: "LAFA",
		name: "Lafarge Zambia"
	},
	{
		ticker: "SHOP",
		name: "Shoprite Holdings"
	},
	{
		ticker: "PUMA",
		name: "Puma Energy Zambia"
	},
	{
		ticker: "NATB",
		name: "National Breweries"
	}
];
var SEED_LOGS = [
	{
		date: "2026-07-29",
		deposit: 10,
		bankBalance: 10,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-07-30",
		deposit: 10,
		bankBalance: 20,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-07-31",
		deposit: 10,
		bankBalance: 30,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-01",
		deposit: 10,
		bankBalance: 40.01,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-02",
		deposit: 10,
		bankBalance: 50.01,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-03",
		deposit: 10,
		bankBalance: 60.01,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-04",
		deposit: 10,
		bankBalance: 70.02,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-05",
		deposit: 10,
		bankBalance: 80.03,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-06",
		deposit: 20,
		bankBalance: 100.04,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-07",
		deposit: 10,
		bankBalance: 110.05,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-08",
		deposit: 10,
		bankBalance: 120.05,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-09",
		deposit: 10,
		bankBalance: 130.06,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-10",
		deposit: 10,
		bankBalance: 140.07,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-11",
		deposit: 20,
		bankBalance: 160.09,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-12",
		deposit: 15,
		bankBalance: 175.09,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-13",
		deposit: 10,
		bankBalance: 185.11,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-14",
		deposit: 15,
		bankBalance: 200.12,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-15",
		deposit: 10,
		bankBalance: 210.15,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-16",
		deposit: 10,
		bankBalance: 220.15,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-17",
		deposit: 7,
		bankBalance: 227.19,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-18",
		deposit: 10,
		bankBalance: 237.23,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-19",
		deposit: 13,
		bankBalance: 250.28,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-20",
		deposit: 10,
		bankBalance: 260.28,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-21",
		deposit: 10,
		bankBalance: 270.34,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-22",
		deposit: 10,
		bankBalance: 280.39,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-23",
		deposit: 20,
		bankBalance: 300.5,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-24",
		deposit: 10,
		bankBalance: 310.5,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-25",
		deposit: 20,
		bankBalance: 330.62,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-26",
		deposit: 15,
		bankBalance: 345.69,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-27",
		deposit: 10,
		bankBalance: 355.69,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-28",
		deposit: 25,
		bankBalance: 380.82,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-29",
		deposit: 20,
		bankBalance: 400.9,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-30",
		deposit: 10,
		bankBalance: 410.9,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-08-31",
		deposit: 10,
		bankBalance: 420.98,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-09-01",
		deposit: 10,
		bankBalance: 431.05,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-09-02",
		deposit: 10,
		bankBalance: 441.29,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-09-03",
		deposit: 10,
		bankBalance: 451.42,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-09-04",
		deposit: 10,
		bankBalance: 461.54,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-09-05",
		deposit: 10,
		bankBalance: 471.67,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-09-06",
		deposit: 20,
		bankBalance: 491.8,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-09-07",
		deposit: 10,
		bankBalance: 501.8,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-09-08",
		deposit: 0,
		bankBalance: 502.07,
		notes: "No Deposit Made"
	},
	{
		date: "2026-09-09",
		deposit: 11,
		bankBalance: 513.2,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-09-10",
		deposit: 19,
		bankBalance: 532.34,
		notes: "Deposited Successfully"
	},
	{
		date: "2026-09-11",
		deposit: 10,
		bankBalance: 542.48,
		notes: "Deposited Successfully"
	}
];
var SEED_MILESTONES = [
	500,
	1e3,
	2e3,
	3e3,
	4e3,
	5e3,
	6e3,
	7e3,
	8e3
].map((threshold) => ({
	threshold,
	dateInvested: "",
	company: "",
	ticker: "",
	amountInvested: null,
	feesConfirmed: false,
	notes: ""
}));
function buildCalendar(logs = SEED_LOGS) {
	const map = new Map(logs.map((l) => [l.date, l]));
	const days = [];
	let iso = START_DATE;
	while (iso <= TARGET_DATE) {
		const log = map.get(iso);
		days.push({
			date: iso,
			deposit: log ? log.deposit : null,
			bankBalance: log ? log.bankBalance : null,
			notes: log?.notes ?? ""
		});
		iso = addDaysISO(iso, 1);
	}
	return days;
}
function mergeCalendar(stored) {
	const fresh = buildCalendar();
	const map = new Map(stored.map((d) => [d.date, d]));
	return fresh.map((d) => map.get(d.date) ?? d);
}
function withViews(days) {
	let cumulative = 0;
	let index = 0;
	return days.map((d) => {
		if (d.deposit != null) cumulative = round2(cumulative + d.deposit);
		const interest = d.bankBalance != null ? round2(d.bankBalance - cumulative) : null;
		index += 1;
		return {
			...d,
			cumulative,
			interest,
			expected: index * 10
		};
	});
}
function computeStats(days, milestones) {
	const today = todayISO();
	const views = withViews(days);
	const elapsed = views.filter((d) => d.date <= today);
	const logged = elapsed.filter((d) => d.deposit != null);
	const withDeposit = logged.filter((d) => (d.deposit ?? 0) > 0);
	const totalDeposited = round2(logged.reduce((s, d) => s + (d.deposit ?? 0), 0));
	const lastBank = [...elapsed].reverse().find((d) => d.bankBalance != null);
	const cashBalance = lastBank?.bankBalance ?? totalDeposited;
	const interest = lastBank?.interest ?? 0;
	const daysElapsed = elapsed.length;
	const expectedByNow = daysElapsed * 10;
	const averageDeposit = logged.length ? round2(totalDeposited / logged.length) : 0;
	const remaining = views.filter((d) => d.date > today).length;
	const projectedTotal = round2(totalDeposited + remaining * averageDeposit);
	const invested = round2(milestones.reduce((s, m) => s + (m.amountInvested ?? 0), 0));
	const { streak, longestStreak } = computeStreaks(elapsed);
	const missedDays = elapsed.filter((d) => d.deposit === 0 || d.deposit === null).length;
	const lastLoggedDate = [...logged].reverse()[0]?.date ?? null;
	return {
		today,
		totalDeposited,
		cashBalance,
		interest,
		daysElapsed,
		daysLogged: logged.length,
		daysWithDeposit: withDeposit.length,
		daysRemaining: remaining,
		averageDeposit,
		expectedByNow,
		paceDelta: round2(totalDeposited - expectedByNow),
		planTarget: PLAN_TARGET,
		progress: PLAN_TARGET ? totalDeposited / PLAN_TARGET : 0,
		streak,
		longestStreak,
		missedDays,
		lastLoggedDate,
		projectedTotal,
		invested,
		netWorth: round2(cashBalance + invested)
	};
}
function computeStreaks(elapsed) {
	let streak = 0;
	let longest = 0;
	let run = 0;
	for (const d of elapsed) if ((d.deposit ?? 0) > 0) {
		run += 1;
		longest = Math.max(longest, run);
	} else run = 0;
	streak = run;
	return {
		streak,
		longestStreak: longest
	};
}
function firstUnloggedDate(days, today) {
	return days.find((d) => d.date <= today && d.deposit === null)?.date ?? today;
}
function crossedOn(days, threshold) {
	return withViews(days).find((d) => d.deposit != null && d.cumulative >= threshold)?.date ?? null;
}
function chartSeries(days, today) {
	return withViews(days).filter((d) => d.date <= today && d.deposit != null).map((d) => ({
		date: d.date,
		deposited: d.cumulative,
		bank: d.bankBalance,
		expected: d.expected,
		label: d.date.slice(5)
	}));
}
function monthKey(iso) {
	return iso.slice(0, 7);
}
function weekdayIndex(iso) {
	return parseISODate(iso).getDay();
}
var useTracker = create()(persist((set, get) => ({
	days: buildCalendar(),
	milestones: SEED_MILESTONES,
	selectedDate: todayISO(),
	burstId: 0,
	hydrated: false,
	setSelectedDate: (date) => set({ selectedDate: date }),
	logDeposit: (payload) => {
		const before = withViews(get().days);
		const prevTotal = (before.find((d) => d.date === payload.date)?.cumulative ?? 0) - (before.find((d) => d.date === payload.date)?.deposit ?? 0 ?? 0);
		set((state) => ({
			days: state.days.map((d) => d.date === payload.date ? {
				...d,
				deposit: payload.deposit,
				bankBalance: payload.bankBalance,
				notes: payload.notes
			} : d),
			selectedDate: payload.date,
			burstId: payload.deposit > 0 ? state.burstId + 1 : state.burstId
		}));
		const newCum = withViews(get().days).find((d) => d.date === payload.date)?.cumulative ?? 0;
		return { crossed: get().milestones.map((m) => m.threshold).filter((t) => prevTotal < t && newCum >= t) };
	},
	updateMilestone: (threshold, patch) => set((state) => ({ milestones: state.milestones.map((m) => m.threshold === threshold ? {
		...m,
		...patch
	} : m) })),
	resetToSeed: () => set({
		days: buildCalendar(),
		milestones: SEED_MILESTONES,
		selectedDate: todayISO()
	}),
	hydrate: () => {
		if (get().hydrated) return;
		const stored = get().days;
		const today = todayISO();
		set({
			days: mergeCalendar(stored),
			selectedDate: firstUnloggedDate(mergeCalendar(stored), today),
			hydrated: true
		});
	}
}), {
	name: "k10-daily-v1",
	skipHydration: true,
	partialize: (state) => ({
		days: state.days,
		milestones: state.milestones
	})
}));
function useTrackerStats() {
	return computeStats(useTracker((s) => s.days), useTracker((s) => s.milestones));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[background-color,color,box-shadow,transform,opacity] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sage/50 disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-sage text-sage-fg hover:bg-sage-2",
			secondary: "bg-panel-2 text-paper shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			ghost: "text-mist hover:bg-panel-2 hover:text-paper",
			outline: "bg-transparent text-paper shadow-[var(--shadow-border)] hover:bg-panel-2 hover:shadow-[var(--shadow-border-hover)]",
			danger: "bg-danger text-paper hover:opacity-90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-[13px]",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var TooltipProvider = Provider;
var Tooltip$1 = Root3;
var TooltipTrigger = Trigger;
var TooltipContent = import_react.forwardRef(({ className, sideOffset = 6, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	sideOffset,
	className: cn("z-50 overflow-hidden rounded-sm bg-panel-2 px-2.5 py-1.5 text-xs text-paper shadow-[var(--shadow-border)]", className),
	...props
}) }));
TooltipContent.displayName = Content2.displayName;
var WEEKDAYS = [
	"S",
	"M",
	"T",
	"W",
	"T",
	"F",
	"S"
];
function intensity(deposit) {
	if (deposit == null) return "bg-transparent shadow-[inset_0_0_0_1px_rgba(232,230,225,0.08)]";
	if (deposit === 0) return "bg-panel-2";
	if (deposit < 10) return "bg-sage/30";
	if (deposit === 10) return "bg-sage/55";
	if (deposit < 20) return "bg-sage/80";
	return "bg-sage";
}
function CalendarHeat() {
	const days = useTracker((s) => s.days);
	const selectedDate = useTracker((s) => s.selectedDate);
	const setSelectedDate = useTracker((s) => s.setSelectedDate);
	const stats = useTrackerStats();
	const [month, setMonth] = (0, import_react.useState)(() => monthKey(stats.today));
	const views = (0, import_react.useMemo)(() => withViews(days), [days]);
	const cells = (0, import_react.useMemo)(() => views.filter((d) => monthKey(d.date) === month), [views, month]);
	const startPad = cells[0] ? weekdayIndex(cells[0].date) : 0;
	const title = cells[0] ? formatDay(cells[0].date, "month") : month;
	function shift(delta) {
		const [y, m] = month.split("-").map(Number);
		const next = new Date(y, (m ?? 1) - 1 + delta, 1);
		const key = `${next.getFullYear()}-${String(next.getMonth() + 1).padStart(2, "0")}`;
		if (key < "2026-07" || key > "2028-07") return;
		setMonth(key);
	}
	const monthTotal = cells.reduce((s, d) => s + (d.deposit ?? 0), 0);
	const loggedCount = cells.filter((d) => d.deposit != null).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-panel p-5 shadow-[var(--shadow-border)] sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl tracking-tight",
					children: "Calendar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-mist",
					children: [
						formatK(monthTotal, 0),
						" this month · ",
						loggedCount,
						" days logged"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							className: "size-9",
							onClick: () => shift(-1),
							"aria-label": "Previous month",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "min-w-[8.5rem] text-center text-sm text-paper",
							children: title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							className: "size-9",
							onClick: () => shift(1),
							"aria-label": "Next month",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TooltipProvider, {
				delayDuration: 80,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 grid grid-cols-7 gap-1.5 text-center text-[10px] tracking-[0.14em] text-haze uppercase",
					children: WEEKDAYS.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: d }, `${d}-${i}`))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 grid grid-cols-7 gap-1.5",
					children: [Array.from({ length: startPad }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {}, `pad-${i}`)), cells.map((d) => {
						const future = d.date > stats.today;
						const selected = d.date === selectedDate;
						const today = d.date === stats.today;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip$1, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: future,
								onClick: () => setSelectedDate(d.date),
								className: cn("aspect-square rounded-sm transition-[transform,box-shadow] duration-150", intensity(future ? null : d.deposit), selected && "ring-2 ring-paper/80 ring-offset-2 ring-offset-panel", today && !selected && "ring-1 ring-sage", !future && "hover:scale-[1.06]", future && "opacity-40"),
								"aria-label": `${formatDay(d.date, "short")}${d.deposit == null ? "" : `, ${formatK(d.deposit, 0)}`}`
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TooltipContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-medium",
							children: formatDay(d.date, "short")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-mist",
							children: future ? "Upcoming" : d.deposit == null ? "Not logged" : d.deposit === 0 ? "Rest day" : formatK(d.deposit, 0)
						})] })] }, d.date);
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-[12px] text-haze",
				children: [parseISODate(stats.today).toLocaleDateString("en-GB", { weekday: "long" }), " — tap a past day to edit it in the log."]
			})
		]
	});
}
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-11 w-full rounded-md bg-ink-2 px-3 text-sm text-paper shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 placeholder:text-haze focus-visible:outline-none focus-visible:shadow-[0_0_0_1px_rgba(126,168,148,0.55)] disabled:cursor-not-allowed disabled:opacity-40", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn("text-[13px] font-medium tracking-wide text-mist", className),
	...props
}));
Label.displayName = Root.displayName;
function DepositForm() {
	const days = useTracker((s) => s.days);
	const selectedDate = useTracker((s) => s.selectedDate);
	const setSelectedDate = useTracker((s) => s.setSelectedDate);
	const logDeposit = useTracker((s) => s.logDeposit);
	const today = useTrackerStats().today;
	const entry = (0, import_react.useMemo)(() => days.find((d) => d.date === selectedDate), [days, selectedDate]);
	const [deposit, setDeposit] = (0, import_react.useState)("10");
	const [bank, setBank] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [justSaved, setJustSaved] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!entry) return;
		setDeposit(entry.deposit == null ? "10" : String(entry.deposit));
		setBank(entry.bankBalance == null ? "" : String(entry.bankBalance));
		setNotes(entry.notes);
		setJustSaved(false);
	}, [entry]);
	const isFuture = selectedDate > today;
	const isToday = selectedDate === today;
	const alreadyLogged = entry?.deposit != null;
	function nudge(delta) {
		const next = Math.max(0, (Number(deposit) || 0) + delta);
		setDeposit(String(next));
	}
	function submit(event) {
		event.preventDefault();
		if (isFuture) return;
		const amount = Number(deposit);
		if (!Number.isFinite(amount) || amount < 0) {
			toast.error("Enter a valid deposit amount.");
			return;
		}
		const bankValue = bank.trim() === "" ? null : Number(bank);
		if (bankValue != null && !Number.isFinite(bankValue)) {
			toast.error("Bank balance must be a number.");
			return;
		}
		const { crossed } = logDeposit({
			date: selectedDate,
			deposit: amount,
			bankBalance: bankValue,
			notes: notes.trim() || (amount > 0 ? "Deposited Successfully" : "No Deposit Made")
		});
		setJustSaved(true);
		window.setTimeout(() => setJustSaved(false), 1400);
		if (amount > 0) toast.success(`Logged ${formatK(amount, 0)} on ${formatDay(selectedDate, "short")}`);
		else toast("Marked as a rest day.");
		for (const t of crossed) toast(`Crossed ${formatK(t, 0)} — ready for a LuSE buy.`, { duration: 5e3 });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-panel p-5 shadow-[var(--shadow-border)] sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl tracking-tight text-paper",
				children: isToday ? "Today’s deposit" : formatDay(selectedDate, "short")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-mist",
				children: alreadyLogged ? "Edit the row — cumulative and interest recalculate live." : "Log the real amount. Leave bank blank if the Patumba SMS isn’t in yet."
			})] }), alreadyLogged ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-1 rounded-full bg-sage-dim px-2.5 py-1 text-[11px] font-medium text-sage-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3" }), " Logged"]
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			className: "mt-5 grid gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "log-date",
						children: "Date"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "log-date",
						type: "date",
						min: START_DATE,
						max: todayISO(),
						value: selectedDate,
						onChange: (e) => setSelectedDate(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "log-amount",
							children: "Deposit (K)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "secondary",
									size: "icon",
									onClick: () => nudge(-1),
									"aria-label": "Decrease",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, {})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "log-amount",
									inputMode: "decimal",
									value: deposit,
									onChange: (e) => setDeposit(e.target.value),
									className: "text-center font-medium tabular-nums"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "secondary",
									size: "icon",
									onClick: () => nudge(1),
									"aria-label": "Increase",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-1.5",
							children: [
								0,
								10,
								15,
								20,
								25
							].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setDeposit(String(n)),
								className: "h-8 rounded-full px-3 text-[12px] text-mist shadow-[var(--shadow-border)] transition-[background-color,color] duration-150 hover:bg-panel-2 hover:text-paper",
								children: n === 0 ? "Skip" : `K${n}`
							}, n))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "log-bank",
						children: "Bank balance from SMS (optional)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "log-bank",
						inputMode: "decimal",
						placeholder: "e.g. 542.48",
						value: bank,
						onChange: (e) => setBank(e.target.value),
						className: "tabular-nums"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "log-notes",
						children: "Notes"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "log-notes",
						value: notes,
						onChange: (e) => setNotes(e.target.value),
						placeholder: "Deposited Successfully"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					size: "lg",
					disabled: isFuture,
					className: "w-full",
					children: justSaved ? "Saved" : alreadyLogged ? "Update entry" : isFuture ? "Future day" : "Record deposit"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[12px] text-haze",
					children: "Plan runs 29 Jul 2026 → 31 Jul 2028. Don’t fill future days."
				})
			]
		})]
	});
}
function ChartTip({ active, payload, label }) {
	if (!active || !payload?.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md bg-panel-2 px-3 py-2 text-xs shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-1 text-mist",
			children: label
		}), payload.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-6 tabular-nums text-paper",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-mist",
				children: p.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p.value == null ? "—" : formatK(p.value) })]
		}, p.name))]
	});
}
function GrowthChart() {
	const days = useTracker((s) => s.days);
	const stats = useTrackerStats();
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	const data = (0, import_react.useMemo)(() => chartSeries(days, stats.today), [days, stats.today]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-panel p-5 shadow-[var(--shadow-border)] sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl tracking-tight",
					children: "Growth"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-mist",
					children: "Deposits vs the K10/day line, with Patumba balance overlaid."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden items-center gap-4 text-[11px] tracking-wide text-mist uppercase sm:flex",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "block size-2 rounded-full bg-sage" }), " Cash"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "block size-2 rounded-full bg-paper/70" }), " Deposited"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "block size-2 rounded-full bg-haze" }), " Pace"]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 h-56 sm:h-64",
				children: mounted && data.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComposedChart, {
						data,
						margin: {
							top: 8,
							right: 8,
							left: -12,
							bottom: 0
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
								id: "cashFill",
								x1: "0",
								y1: "0",
								x2: "0",
								y2: "1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
									offset: "0%",
									stopColor: "#7ea894",
									stopOpacity: .28
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
									offset: "100%",
									stopColor: "#7ea894",
									stopOpacity: 0
								})]
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
								stroke: "#2a2d2a",
								vertical: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "label",
								tick: {
									fill: "#8b8f8a",
									fontSize: 11
								},
								tickLine: false,
								axisLine: false,
								interval: "preserveStartEnd",
								minTickGap: 28
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								tick: {
									fill: "#8b8f8a",
									fontSize: 11
								},
								tickLine: false,
								axisLine: false,
								tickFormatter: (v) => v >= 1e3 ? `${v / 1e3}k` : String(v),
								width: 40
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTip, {}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
								type: "monotone",
								dataKey: "bank",
								name: "Patumba",
								stroke: "#7ea894",
								fill: "url(#cashFill)",
								strokeWidth: 2,
								dot: false,
								connectNulls: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								type: "monotone",
								dataKey: "deposited",
								name: "Deposited",
								stroke: "#e8e6e1",
								strokeWidth: 1.5,
								dot: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								type: "monotone",
								dataKey: "expected",
								name: "K10 pace",
								stroke: "#5c605c",
								strokeWidth: 1,
								strokeDasharray: "4 4",
								dot: false
							})
						]
					})
				}) : data.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-full items-center justify-center text-sm text-mist",
					children: "Waiting for deposits"
				}) : null
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-[12px] text-haze",
				children: [
					"At the current ",
					formatK(stats.averageDeposit, 0),
					" average, the plan lands near",
					" ",
					formatK(stats.projectedTotal, 0),
					" by July 2028."
				]
			})
		]
	});
}
function AnimatedNumber({ value, decimals = 2, className, prefix = true }) {
	const [display, setDisplay] = (0, import_react.useState)(value);
	const current = (0, import_react.useRef)(value);
	const first = (0, import_react.useRef)(true);
	(0, import_react.useEffect)(() => {
		if (first.current) {
			first.current = false;
			current.current = value;
			setDisplay(value);
			return;
		}
		const from = current.current;
		const to = value;
		const start = performance.now();
		const duration = 700;
		let frame = 0;
		const tick = (now) => {
			const t = Math.min(1, (now - start) / duration);
			const eased = 1 - Math.pow(1 - t, 3);
			const next = from + (to - from) * eased;
			current.current = next;
			setDisplay(next);
			if (t < 1) frame = requestAnimationFrame(tick);
		};
		frame = requestAnimationFrame(tick);
		return () => cancelAnimationFrame(frame);
	}, [value]);
	const formatted = prefix ? formatK(display, decimals) : display.toLocaleString("en-ZM", {
		minimumFractionDigits: decimals,
		maximumFractionDigits: decimals
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("tabular-nums", className),
		children: formatted
	});
}
function ProgressRing({ progress, size = 236, stroke = 7, children, className, burst }) {
	const radius = (size - stroke) / 2;
	const len = 2 * Math.PI * radius;
	const offset = len * (1 - Math.min(1, Math.max(0, progress)));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative", className),
		style: {
			width: size,
			height: size
		},
		children: [
			burst ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "burst-ring pointer-events-none absolute inset-3 rounded-full border border-sage/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "burst-ring pointer-events-none absolute inset-0 rounded-full border border-sage/25",
				style: { animationDelay: "90ms" }
			})] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				width: size,
				height: size,
				className: "-rotate-90",
				"aria-hidden": "true",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: size / 2,
					cy: size / 2,
					r: radius,
					fill: "none",
					stroke: "currentColor",
					className: "text-line",
					strokeWidth: stroke
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: size / 2,
					cy: size / 2,
					r: radius,
					fill: "none",
					stroke: "currentColor",
					className: "text-sage",
					strokeWidth: stroke,
					strokeLinecap: "round",
					strokeDasharray: len,
					strokeDashoffset: offset,
					style: { transition: "stroke-dashoffset 700ms cubic-bezier(0.22, 1, 0.36, 1)" }
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 flex flex-col items-center justify-center px-8 text-center",
				children
			})
		]
	});
}
function HeroPanel() {
	const stats = useTrackerStats();
	const burstId = useTracker((s) => s.burstId);
	const [ringSize, setRingSize] = (0, import_react.useState)(220);
	(0, import_react.useEffect)(() => {
		const apply = () => setRingSize(window.innerWidth < 640 ? 208 : 248);
		apply();
		window.addEventListener("resize", apply);
		return () => window.removeEventListener("resize", apply);
	}, []);
	const pct = Math.round(stats.progress * 1e3) / 10;
	const paceLabel = stats.paceDelta > 0 ? `${formatK(stats.paceDelta, 0)} ahead of K10/day` : stats.paceDelta < 0 ? `${formatK(Math.abs(stats.paceDelta), 0)} behind K10/day` : "Exactly on the K10/day pace";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "stagger-in flex flex-col items-center pt-4 pb-2 sm:pt-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[13px] tracking-[0.22em] text-mist uppercase",
				children: "Patumba · running total"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ProgressRing, {
				progress: stats.progress,
				burst: burstId > 0,
				className: "mt-4",
				size: ringSize,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatedNumber, {
					value: stats.cashBalance,
					className: "font-display text-[2.75rem] leading-none tracking-tight text-paper sm:text-5xl"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "mt-2 max-w-[11rem] text-[12px] leading-snug text-mist",
					children: [
						pct,
						"% of ",
						formatK(stats.planTarget, 0)
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-sm text-center text-sm text-paper/80",
				children: paceLabel
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-[12px] text-haze",
				children: [
					"Target ",
					formatDay(TARGET_DATE, "short"),
					" · ",
					stats.daysRemaining,
					" days left"
				]
			})
		]
	});
}
function HydrateGate({ children }) {
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		(async () => {
			await useTracker.persist.rehydrate();
			if (!cancelled) useTracker.getState().hydrate();
		})();
		return () => {
			cancelled = true;
		};
	}, []);
	return children;
}
function LedgerTable() {
	const days = useTracker((s) => s.days);
	const selectedDate = useTracker((s) => s.selectedDate);
	const setSelectedDate = useTracker((s) => s.setSelectedDate);
	const stats = useTrackerStats();
	const [filter, setFilter] = (0, import_react.useState)("recent");
	const views = (0, import_react.useMemo)(() => withViews(days), [days]);
	const rows = (0, import_react.useMemo)(() => {
		const elapsed = views.filter((d) => d.date <= stats.today);
		if (filter === "logged") return [...elapsed].filter((d) => d.deposit != null).reverse();
		if (filter === "gaps") return [...elapsed].filter((d) => d.deposit == null || d.deposit === 0).reverse();
		return [...elapsed].slice(-14).reverse();
	}, [
		views,
		stats.today,
		filter
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-panel p-5 shadow-[var(--shadow-border)] sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl tracking-tight",
					children: "Ledger"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-mist",
					children: "The daily book. Select a row to edit it in the log."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1 rounded-full bg-ink-2 p-1",
					children: [
						["recent", "Recent"],
						["logged", "Logged"],
						["gaps", "Gaps"]
					].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setFilter(id),
						className: cn("h-8 rounded-full px-3 text-[12px] font-medium transition-[background-color,color] duration-150", filter === id ? "bg-panel text-paper" : "text-mist hover:text-paper"),
						children: label
					}, id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[36rem] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-[11px] tracking-[0.14em] text-haze uppercase",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-line",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 pr-3 font-medium",
									children: "Date"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 pr-3 font-medium",
									children: "Deposit"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 pr-3 font-medium",
									children: "Cumulative"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 pr-3 font-medium",
									children: "Bank"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 pr-3 font-medium",
									children: "Interest"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-medium",
									children: "Notes"
								})
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 6,
						className: "py-8 text-center text-mist",
						children: "Nothing in this view."
					}) }) : rows.map((row) => {
						const selected = row.date === selectedDate;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							onClick: () => setSelectedDate(row.date),
							className: cn("cursor-pointer border-b border-line/70 transition-colors duration-150", selected ? "bg-sage-dim/50" : "hover:bg-panel-2"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 pr-3 whitespace-nowrap text-paper",
									children: formatDay(row.date, "short")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 pr-3 tabular-nums",
									children: row.deposit == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-haze",
										children: "—"
									}) : formatK(row.deposit, row.deposit % 1 ? 2 : 0)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 pr-3 tabular-nums text-mist",
									children: formatK(row.cumulative, 0)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 pr-3 tabular-nums",
									children: row.bankBalance == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-haze",
										children: "—"
									}) : formatK(row.bankBalance)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 pr-3 tabular-nums text-sage-2",
									children: row.interest == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-haze",
										children: "—"
									}) : formatK(row.interest)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "max-w-[12rem] truncate py-2.5 text-mist",
									children: row.notes || "—"
								})
							]
						}, row.date);
					}) })]
				})
			}),
			filter === "recent" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: () => setFilter("logged"),
					children: "Show every logged day"
				})
			}) : null
		]
	});
}
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-ink/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed top-1/2 left-1/2 z-50 grid w-[calc(100%-2rem)] max-w-lg -translate-x-1/2 -translate-y-1/2 gap-4 rounded-xl bg-panel p-6 shadow-[var(--shadow-border)] duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute top-4 right-4 rounded-sm text-mist transition-opacity hover:text-paper focus:outline-none focus:ring-2 focus:ring-sage/40",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1.5", className),
		...props
	});
}
function DialogFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
		...props
	});
}
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("font-display text-xl font-medium tracking-tight text-paper", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-mist", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
function MilestoneTrack() {
	const days = useTracker((s) => s.days);
	const milestones = useTracker((s) => s.milestones);
	const updateMilestone = useTracker((s) => s.updateMilestone);
	const [open, setOpen] = (0, import_react.useState)(null);
	const rows = (0, import_react.useMemo)(() => milestones.map((m) => ({
		...m,
		crossed: crossedOn(days, m.threshold)
	})), [days, milestones]);
	const active = rows.find((r) => r.threshold === open) ?? null;
	const nextReady = rows.find((r) => r.crossed && r.amountInvested == null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-panel p-5 shadow-[var(--shadow-border)] sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl tracking-tight",
					children: "LuSE milestones"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-xl text-sm text-mist",
					children: "When the pot crosses a rung, move that chunk into shares instead of waiting until 2028."
				})] }), nextReady ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "self-start rounded-full bg-sage-dim px-3 py-1 text-[12px] font-medium text-sage-2",
					children: [formatK(nextReady.threshold, 0), " ready to invest"]
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-6 space-y-2",
				children: rows.map((row, i) => {
					const invested = row.amountInvested != null && row.amountInvested > 0;
					const ready = !!row.crossed && !invested;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setOpen(row.threshold),
						className: cn("flex w-full items-center gap-4 rounded-lg px-3 py-3 text-left transition-[background-color,box-shadow] duration-150 sm:px-4", ready && "bg-sage-dim/60 shadow-[var(--shadow-border)]", invested && "bg-ink-2", !ready && !invested && "hover:bg-panel-2"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("grid size-9 shrink-0 place-items-center rounded-full text-[12px] font-medium", invested && "bg-sage text-sage-fg", ready && "bg-sage/30 text-sage-2", !ready && !invested && "bg-panel-2 text-haze"),
								children: invested ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : i + 1
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex flex-wrap items-baseline gap-x-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium tabular-nums text-paper",
										children: formatK(row.threshold, 0)
									}), invested ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate text-sm text-mist",
										children: row.company || row.ticker || "Trade recorded"
									}) : ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-sm text-sage-2",
										children: ["Threshold crossed ", formatDay(row.crossed, "short")]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm text-haze",
										children: "Upcoming"
									})]
								}), invested && row.amountInvested != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block text-[12px] text-mist",
									children: [
										formatK(row.amountInvested),
										" deployed",
										row.dateInvested ? ` · ${formatDay(row.dateInvested, "short")}` : ""
									]
								}) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden text-[12px] text-haze sm:inline",
								children: invested ? "Edit" : ready ? "Record buy" : "Prep"
							})
						]
					}) }, row.threshold);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "mt-5 flex gap-3 rounded-lg bg-ink-2 p-4 text-sm text-mist",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "mt-0.5 size-4 shrink-0 text-sage" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Before the first kwacha hits the exchange, call a licensed broker (Pangaea Securities or Stockbrokers Zambia) and ask: minimum trade size, fee per trade, and any account minimums. That answer decides small frequent buys versus fewer larger ones." })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvestDialog, {
				row: active,
				onClose: () => setOpen(null),
				onSave: (patch) => {
					if (!active) return;
					updateMilestone(active.threshold, patch);
					setOpen(null);
					toast.success(patch.amountInvested ? `Recorded ${formatK(patch.amountInvested)} in ${patch.company || "LuSE"}` : "Milestone updated");
				}
			})
		]
	});
}
function InvestDialog({ row, onClose, onSave }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: !!row,
		onOpenChange: (v) => {
			if (!v) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			className: "bg-panel",
			children: row ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvestForm, {
				row,
				onClose,
				onSave
			}, row.threshold) : null
		})
	});
}
function InvestForm({ row, onClose, onSave }) {
	const [company, setCompany] = (0, import_react.useState)(row.company);
	const [ticker, setTicker] = (0, import_react.useState)(row.ticker);
	const [amount, setAmount] = (0, import_react.useState)(row.amountInvested == null ? String(row.threshold) : String(row.amountInvested));
	const [date, setDate] = (0, import_react.useState)(row.dateInvested || todayISO());
	const [fees, setFees] = (0, import_react.useState)(row.feesConfirmed);
	const [notes, setNotes] = (0, import_react.useState)(row.notes);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: [formatK(row.threshold, 0), " rung"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: row.crossed ? `Savings crossed this level on ${formatDay(row.crossed, "short")}. Record the actual buy when it happens.` : "Prep the trade. Fill this in once the broker confirms." })] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "ms-counter",
						children: "Counter"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						id: "ms-counter",
						value: ticker,
						onChange: (e) => {
							const t = e.target.value;
							setTicker(t);
							const hit = LUSE_COUNTERS.find((c) => c.ticker === t);
							if (hit) setCompany(hit.name);
						},
						className: "flex h-11 w-full rounded-md bg-ink-2 px-3 text-sm text-paper shadow-[var(--shadow-border)] focus-visible:outline-none focus-visible:shadow-[0_0_0_1px_rgba(126,168,148,0.55)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Choose a LuSE counter"
							}),
							LUSE_COUNTERS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: c.ticker,
								children: [
									c.ticker,
									" — ",
									c.name
								]
							}, c.ticker)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "OTHER",
								children: "Other"
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "ms-company",
						children: "Company"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "ms-company",
						value: company,
						onChange: (e) => setCompany(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "ms-amount",
							children: "Amount invested (K)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "ms-amount",
							inputMode: "decimal",
							className: "tabular-nums",
							value: amount,
							onChange: (e) => setAmount(e.target.value)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "ms-date",
							children: "Trade date"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "ms-date",
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value)
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex min-h-11 items-center gap-2 text-sm text-mist",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: fees,
						onChange: (e) => setFees(e.target.checked),
						className: "size-4 rounded-sm accent-sage"
					}), "Broker fees confirmed"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "ms-notes",
						children: "Notes"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "ms-notes",
						value: notes,
						onChange: (e) => setNotes(e.target.value)
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			onClick: onClose,
			children: "Cancel"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			onClick: () => {
				onSave({
					company: company || LUSE_COUNTERS.find((c) => c.ticker === ticker)?.name || "",
					ticker,
					amountInvested: amount === "" ? null : Number(amount),
					dateInvested: date,
					feesConfirmed: fees,
					notes
				});
			},
			children: "Save trade"
		})] })
	] });
}
function StatStrip() {
	const s = useTrackerStats();
	const items = [
		{
			label: "Deposited",
			value: s.totalDeposited,
			kind: "money"
		},
		{
			label: "Interest",
			value: s.interest,
			kind: "money"
		},
		{
			label: "Invested",
			value: s.invested,
			kind: "money"
		},
		{
			label: "Avg / day",
			value: s.averageDeposit,
			kind: "money"
		},
		{
			label: "Streak",
			value: s.streak,
			kind: "count"
		},
		{
			label: "Logged",
			value: s.daysLogged,
			kind: "count"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "mt-6 grid grid-cols-2 gap-px overflow-hidden rounded-xl bg-line sm:grid-cols-3 lg:grid-cols-6",
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bg-panel px-4 py-4 sm:px-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-[11px] tracking-[0.16em] text-mist uppercase",
				children: item.label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1.5 font-display text-2xl tracking-tight text-paper",
				children: item.kind === "money" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatedNumber, {
					value: item.value,
					decimals: item.label === "Interest" ? 2 : 0
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular-nums",
					children: item.value
				})
			})]
		}, item.label))
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HydrateGate, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrackerPage, {}) });
}
function TrackerPage() {
	const resetToSeed = useTracker((s) => s.resetToSeed);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if ((e.metaKey || e.ctrlKey) && e.key === "k") {
				e.preventDefault();
				document.getElementById("log-amount")?.focus();
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
			theme: "dark",
			position: "top-center",
			toastOptions: { className: "!bg-panel-2 !text-paper !border-0 !shadow-[0_0_0_1px_rgba(232,230,225,0.08)]" }
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid items-start gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(22rem,26rem)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroPanel, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:pt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DepositForm, {})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatStrip, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-6 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GrowthChart, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarHeat, {})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MilestoneTrack, {})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerTable, {})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
			className: "mt-10 flex flex-col items-start justify-between gap-3 border-t border-line pt-6 pb-4 text-[12px] text-haze sm:flex-row sm:items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "K10 a day from 29 Jul 2026 to 31 Jul 2028. Numbers stay on this device." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "sm",
				className: "h-8 text-haze",
				onClick: () => {
					if (window.confirm("Restore the original spreadsheet figures?")) resetToSeed();
				},
				children: "Restore spreadsheet"
			})]
		})
	] });
}
//#endregion
export { Home as component };
